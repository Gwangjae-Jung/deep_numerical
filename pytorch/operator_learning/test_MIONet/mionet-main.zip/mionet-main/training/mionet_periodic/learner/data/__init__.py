"""
@author: jpzxshi
"""
from .data import Data

__all__ = [
    'Data',
]
